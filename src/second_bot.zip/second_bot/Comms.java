package second_bot;

import battlecode.common.*;

public class Comms {
    
}