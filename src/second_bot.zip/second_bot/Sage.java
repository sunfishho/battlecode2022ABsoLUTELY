
package second_bot;

import battlecode.common.*;


public class Sage extends RobotCommon{

    public Sage(RobotController rc, int r, MapLocation loc){
        super(rc, r, loc);
    }

    //TODO
    public void takeTurn() throws GameActionException {
    }
}