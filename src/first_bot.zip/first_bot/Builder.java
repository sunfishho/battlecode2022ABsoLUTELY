
package first_bot;

import battlecode.common.*;


public class Builder extends RobotCommon{

    public Builder(RobotController rc){
        super(rc);
        //do more stuff later
    }

    //TODO
    public void takeTurn() throws GameActionException {
    }
}