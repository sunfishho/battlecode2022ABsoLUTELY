
package first_bot;

import battlecode.common.*;


public class Watchtower extends RobotCommon{

    public Watchtower(RobotController rc){
        super(rc);
        //do more stuff later
    }

    //TODO
    public void takeTurn() throws GameActionException {
    }
}