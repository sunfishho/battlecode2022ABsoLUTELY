
package first_bot;

import battlecode.common.*;


public class Laboratory extends RobotCommon{

    public Laboratory(RobotController rc){
        super(rc);
        //do more stuff later
    }

    //TODO
    public void takeTurn() throws GameActionException {
    }
}