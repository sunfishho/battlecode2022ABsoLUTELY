
package first_bot;

import battlecode.common.*;


public class Sage extends RobotCommon{

    public Sage(RobotController rc){
        super(rc);
        //do more stuff later
    }

    //TODO
    public void takeTurn() throws GameActionException {
    }
}